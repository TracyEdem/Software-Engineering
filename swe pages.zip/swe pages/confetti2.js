document.querySelector(".btn.btn-primary.ready").addEventListener("click", function (e) {    
  party.confetti(this);});